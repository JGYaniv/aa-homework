require_relative "./dictionary.rb"
class Hangman
  DICTIONARY = MY_DICTIONARY
  attr_reader :guess_word, :attempted_chars, :remaining_incorrect_guesses
  
  def self.random_word
    DICTIONARY.sample
  end

  def initialize(ai=false)
    @secret_word = Hangman::random_word
    @guess_word = Array.new(@secret_word.length){"_"}
    @attempted_chars = []
    @remaining_incorrect_guesses = 5
    @ai = ai
    @ai_player = AiPlayer.new(self)
  end

  def already_attempted?(char)
    @attempted_chars.include?(char)
  end

  def get_matching_indices(char)
    matching_indices = []
    @secret_word.each_char.with_index do |letter, idx|
      matching_indices << idx if char == letter
    end
    matching_indices
  end

  def fill_indices(char, indices)
    indices.each do |idx|
      @guess_word[idx] = char
    end
  end

  def try_guess(char)
    if already_attempted?(char)
      print "that has already been attempted"
      false
    else
      @attempted_chars << char
      indices = get_matching_indices(char)
      if indices.empty?
        @remaining_incorrect_guesses -= 1
      else
        fill_indices(char, indices)

      end
      true
    end
  end
  
  def ask_user_for_guess
    if @ai == false
      print "Enter a char:"
      guess = gets.chomp
      try_guess(guess)
    elsif @ai == true
      # picks a random letter
      # alpha variable, pick a random index
      # passes random letter to try_guess
      print "Enter a char:"
      guess = @ai_player.makes_a_guess(self)
      puts "___%$!@#%^& AI IS TRYING: #{guess}___"
      sleep(1)
      try_guess(guess)
    end
  end

  def win?
    if @guess_word.join("") == @secret_word
      puts "WIN"
      return true
    else
      return false
    end
  end

  def lose?
    if @remaining_incorrect_guesses == 0
      puts "LOSE"
      return true
    else
      return false
    end
  end

  def game_over?
    if win? || lose?
      puts @secret_word
      return true
    else
      return false
    end
    
  end
end


class AiPlayer
  def initialize(game_state)
    @game_state = game_state
    @possible_words = Hangman::DICTIONARY
  end

  def reduce_possible
    current_guess_word = @game_state.guess_word
    word_length = @game_state.guess_word.length
    
    @possible_words.select! do |word| 
      word.length == word_length &&
      matching_letters?(word)
    end
  end

  def matching_letters?(word)
    #returns true if the letters correctly guessed so far match the indices of word
    current_guess_word = @game_state.guess_word
    word.each_char.with_index do |char, idx|
      current_letter = current_guess_word[idx]
      if current_letter != char && current_letter != "_"
        return false
      end
    end
    true
  end

  def makes_a_guess(new_game_state)
    @game_state = new_game_state
    reduce_possible
    letters = @possible_words.sample.chars
    letters.each do |letter|
      vowels = "aeioueariotns"
      if vowels.include?(letter) && !@game_state.attempted_chars.include?(letter)
        return letter
      end
    end
    letters.each do |letter|
      if !@game_state.attempted_chars.include?(letter)
        return letter
      end
    end
  end
end
